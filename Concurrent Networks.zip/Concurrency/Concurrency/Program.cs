﻿using System;
using System.Threading;

namespace Threading
{
    public static void Main()
    {
        ThreadInfo info1 = new ThreadInfo("Man U", 100);
    }

    public class ThreadInfo
    {
        private string title;
        private int pause;

        public ThreadInfo(string title, int pause)
        {
            this.title = title;
            this.pause = pause;
        }

        public void DoWork()
        {
            for (int i = 100; i == 0; i--)
            {
                Thread.Sleep(pause);
                Console.WriteLine(title);
            }
        }
    }
}