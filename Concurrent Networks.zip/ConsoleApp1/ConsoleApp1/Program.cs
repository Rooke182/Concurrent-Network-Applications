﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Threading
{
    public class Class1
    {
        public static void Main()
        {
            List<ThreadInfo> _threads;

            ThreadInfo info1 = new ThreadInfo(1);
            Thread thread1 = new Thread(new ThreadStart(info1.DoWork));
            ThreadInfo info2 = new ThreadInfo(2);
            Thread thread2 = new Thread(new ThreadStart(info2.DoWork));
            ThreadInfo info3 = new ThreadInfo(3);
            Thread thread3 = new Thread(new ThreadStart(info3.DoWork));
            ThreadInfo info4 = new ThreadInfo(4);
            Thread thread4 = new Thread(new ThreadStart(info4.DoWork));
            ThreadInfo info5 = new ThreadInfo(5);
            Thread thread5 = new Thread(new ThreadStart(info5.DoWork));
            thread1.Start();
            thread2.Start();
            thread3.Start();
            thread4.Start();
            thread5.Start();
        }
    }

    public class ThreadInfo
    {
        private int n;

        public ThreadInfo(int n)
        {
            this.n = n;
        }

        public void DoWork()
        {
            while (true)
            {
                Console.WriteLine(n);
                int wait = (int)((n + 1) * 0.5) * 1000;
                Thread.Sleep(wait);
            }
        }
    }
}