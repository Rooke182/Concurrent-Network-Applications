﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Threading_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num = 0;
            while (true)
            {
                
                int half = num / 2;
                int numToCheck = 2;
                bool isNotPrime = false;
                while (!isNotPrime)
                {
                    if (numToCheck >= half)
                    {
                        Console.WriteLine(num);
                        num += 1;
                        isNotPrime = true;
                    }
                    if (numToCheck < half)
                    {
                        if (num % numToCheck == 0)
                        {
                            isNotPrime = true;
                            num += 1;
                        }
                    }
                    numToCheck++;
                }
            }
        }
    }
}
