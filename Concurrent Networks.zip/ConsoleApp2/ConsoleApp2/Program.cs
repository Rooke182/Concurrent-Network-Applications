﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Timers;

namespace CNA_Week_2
{
    internal class Task4WithOutThreads
    {
        List<int> primes = new List<int>();
        int numbers = 1;

        static void Main(string[] args)
        {
            Task4WithOutThreads task4WithoutThreads = new Task4WithOutThreads(1000);
        }

        public Task4WithOutThreads(double time)
        {
            while (true)
            {
                CheckIfPrime(numbers);
                numbers++;
            }

            Console.WriteLine("Primers found = ");

            foreach (int i in primes)
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("Number of primes found = " + primes.Count);

            Console.ReadLine();
        }

        public void CheckIfPrime(int numToCheck)
        {
            double sqrt = Math.Sqrt(numToCheck);
            bool isPrime = true;

            if (sqrt % 1 != 0)
            {
                int checker = 2;

                while (checker < sqrt)
                {
                    float mod = (float)numToCheck / checker % 1;
                    if (mod != 0)
                    {
                        checker++;
                    }
                    else
                    {
                        isPrime = false;
                        break;
                    }
                }
            }
            else
                isPrime = false;

            if (isPrime)
            {
                primes.Add(numToCheck);
            }
        }
    }
}
